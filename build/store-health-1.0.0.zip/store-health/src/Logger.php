<?php
/**
 * Minimal PSR-3-flavoured logger that never leaks secrets.
 *
 * Entries are stored in a capped list in a single private wp_option (not a
 * database table, to keep the scaffold dependency-free) and are only ever
 * shown to users with the manage_options capability. Known secret-shaped
 * keys (api_key, token, password, secret, license) are redacted from any
 * associative context array before storage.
 *
 * @package AnsariAi\StoreHealth
 */

declare(strict_types=1);

namespace AnsariAi\StoreHealth;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Logger {

	private const OPTION_KEY  = 'ansariai_sh_log';
	private const MAX_ENTRIES = 200;

	/** @var string[] */
	private const SECRET_KEY_PATTERNS = array( 'key', 'token', 'secret', 'password', 'license', 'auth' );

	public static function info( string $message, array $context = array() ): void {
		self::write( 'info', $message, $context );
	}

	public static function warning( string $message, array $context = array() ): void {
		self::write( 'warning', $message, $context );
	}

	public static function error( string $message, array $context = array() ): void {
		self::write( 'error', $message, $context );
	}

	private static function write( string $level, string $message, array $context ): void {
		$entries = get_option( self::OPTION_KEY, array() );

		if ( ! is_array( $entries ) ) {
			$entries = array();
		}

		$entries[] = array(
			'time'    => time(),
			'level'   => $level,
			'message' => $message,
			'context' => self::redact( $context ),
		);

		if ( count( $entries ) > self::MAX_ENTRIES ) {
			$entries = array_slice( $entries, -self::MAX_ENTRIES );
		}

		update_option( self::OPTION_KEY, $entries, false );
	}

	/**
	 * @param array<string,mixed> $context
	 *
	 * @return array<string,mixed>
	 */
	private static function redact( array $context ): array {
		foreach ( $context as $key => $value ) {
			$lower_key = strtolower( (string) $key );

			foreach ( self::SECRET_KEY_PATTERNS as $pattern ) {
				if ( str_contains( $lower_key, $pattern ) ) {
					$context[ $key ] = '***redacted***';

					continue 2;
				}
			}

			if ( is_array( $value ) ) {
				$context[ $key ] = self::redact( $value );
			}
		}

		return $context;
	}

	/**
	 * @return array<int,array{time:int,level:string,message:string,context:array<string,mixed>}>
	 */
	public static function entries(): array {
		$entries = get_option( self::OPTION_KEY, array() );

		return is_array( $entries ) ? $entries : array();
	}

	public static function clear(): void {
		delete_option( self::OPTION_KEY );
	}
}
